from django import forms
#import model class from models.py
#from app_name.models import model_name
from customerprofile.models import Customermodel

class CustomerForm(forms.ModelForm):
    class Meta:
        model=Customermodel
        fields="__all__"
