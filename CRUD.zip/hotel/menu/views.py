from tkinter import E
from django.shortcuts import render,HttpResponse,redirect
from menu.form import MenuForm
from menu.models import Menumodel
def index1(request):
    if request.method=="POST":
        form=MenuForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('../show1')
        else:
            pass
    else:
        obj=MenuForm()
        return render(request,'index1.html',{'stu':obj})
        
def show1(request):  
        students = Menumodel.objects.all()
        return render(request,"show1.html",{'stu_list':students})


def edit1(request, id):  
        stu = Menumodel.objects.get(id=id)  
        return render(request,'edit1.html', {'stu':stu})

def update1(request, id):  
        stu =Menumodel.objects.get(id=id)  
        form=MenuForm(request.POST, instance = stu)  
        if form.is_valid():  
            form.save()  
            return redirect("../show1")
        return render(request, 'edit1.html', {'stu': stu})  

def destroy1(request, id):  
    stu=Menumodel.objects.get(id=id)  
    stu.delete() 
    return redirect("../show1") 

def new_func():
    return redirect('show1')
    
    
def upload1(request):
    obj=MenuForm()
    return render(request,'upload1.html',{'stu':obj})



