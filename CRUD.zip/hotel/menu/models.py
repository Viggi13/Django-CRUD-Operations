from django.db import models
# Create your models here.

class Menumodel(models.Model):
    menuname=models.CharField(max_length=100)
    price=models.IntegerField()
    quantity=models.CharField(max_length=100)

    def __str__(self):
        return str(self.menuname)+" "+str(self.quantity)

    class Meta:
        db_table='menus'

