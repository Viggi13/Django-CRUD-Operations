# from django.contrib import admin
from django.urls import path
# from customer_data import views
from menu import views

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('menu/',views.index1,name="Menu-home"),
    path('show1/',views.show1,name="Display Menu List"),
    path('edit1/<int:id>',views.edit1,name="Edit Menu List"),
    path('update1/<int:id>',views.update1,name='Update Menu'),
    path('delete1/<int:id>',views.destroy1,name="Delete Menu Record"),
]